# Peer A acceptance ledger

Scope: dsh-peer only. This package does not consume dsh-projects product step numbers. Frozen defaults and acceptance IDs are in implementation.md; thresholds are unchanged.

## Failure ledger

| ID | Trigger and mechanism | Forced regression |
|---|---|---|
| L-peer-001 | Two agents repeatedly acknowledge; new random IDs bypassed ID-only dedup and no directional admission limits existed | Red: baseline core.deliver, test/loop-control.test.mjs G01/G03/G05/G06/G07; 12/12 old behavior failures in test/evidence/red-loop.tap |
| L-peer-002 | Receive and send records lacked source-scoped display contract and ambiguous delivery handling | Red: baseline core.deliver/send, test/render-contract.test.mjs UI01/UI02; test/evidence/red-render-contract.tap |
| L-peer-003 | Independent review found missing mandatory Markdown labels and command-based read queries polluting chat | Red: test/client.test.mjs UI05, test/evidence/red-markdown-labels.tap. Read query moved to owner-only Fetch; no peer-status command remains |
| L-peer-004 | Real Host rejects remote.commands access without declaring injection, hiding receive cards | Red: test/evidence/red-host-inject.json and red-host-inject.tap; UI03 now declares the service, packed browser cards visible |
| L-peer-005 | Initial eval runner could exceed send budget in one response, pass keyword-only reports and overwrite evidence | test/eval-contract.test.mjs checks per-call budget and missing collaboration; unique batch files and partial-error records; no model runs were made with that initial runner |
| L-peer-006 | First provider adapter omitted stop_reason; duplicate representations inflated the request budget estimate | Red: test/evidence/red-eval-stop-reason.tap. First batch preserved as interrupted, stop reasons and provider input counter added; follow-up batch is independent |
| L-peer-007 | E05 exceeds remaining fixed budget in both versions; E06 changed run 0 completes results but extra query triggers duplicate rejection | eval/results/batch-PfMF7u/report.md and original run JSON; frozen pass line remains failed; no post-run threshold changes |

## Coverage

| Feature | Tests/scenarios | Current evidence |
|---|---|---|
| F-peer-A-01 exact dedup/identity | G01/G02/G07/G09; S01/S04 | unit/scenario logs |
| F-peer-A-02 windows and persistent pause | G03–G06/G12; S02/S03 | unit/scenario logs |
| F-peer-A-03 recovery/compatibility | G08/G09; UI03; S03/S05 | root identity, idempotent user command, v1 fixture |
| F-peer-A-04 failure/capacity | G10/G11/G12; S04/S06 | rollback, reservations, capacity, cleanup |
| F-peer-A-05 presentation | UI01–UI05 | source/DOM tests and packed real Host: test/evidence/browser/result.json |
| F-peer-A-06 packaging | REL01–REL03 | test/evidence/pack.json; browser/result.json; browser-no-client/result.json and browser-baseline/result.json |

## Model rules

`peer_send` and the received envelope say: new work, questions, substantive progress or results only; no acknowledgement/thanks/farewell replies; result once; stop automatic sends after protection errors; receipt is not processing or user-task completion. Runtime guard enforces limits independent of prompt compliance. E01–E06 are not substitutes for G/S tests.

## Open validation

E01–E06: completed, **not passed**. The standalone follow-up batch `eval/results/batch-PfMF7u/report.md` contains all 60 runs: changed quiet cases 15/15; normal cases 9/15; five token-cap failures and one duplicate-content rejection. E05 fails the fixed budget in both versions. E06’s failed changed run completes the result, but an extra query causes a duplicate resend. The first interrupted batch is separate and never pooled into scores. No universal token-saving claim.

History pagination passed (`browser-history/result.json`); a separate Desktop loading path and Windows remain untested. Final deterministic suite: 42/42, S scenarios: 6/6; packed browser and independent read-only product review passed. Full A acceptance remains open because the model pass line has not been met.

First E batch `eval/results/batch-g3j0uB` is retained as interrupted harness evidence, not final acceptance: provider termination was not recorded and duplicated transcript fields inflated the conservative UTF-8 budget estimate. Completed E05 samples were marked token-cap; one in-flight request may be unaccounted after termination. A follow-up batch uses the provider's input-token count with a 32-token reserve, logs the request output ceiling and actual stop reason, treats truncation as failure, and preserves partial runs on graceful interruption. No case, run count, total budget or pass threshold is changed. `test/evidence/red-eval-stop-reason.tap` demonstrates the missing stop-reason record before repair.
