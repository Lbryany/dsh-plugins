import { test } from 'node:test';
import assert from 'node:assert/strict';
import { setup } from './helpers.mjs';
test('UI01/UI04 receive metadata identifies exact original Unicode body', async t => {
  const h = await setup(t); const original = '首行😀\n第二行\n```js\nconst x = 1;\n```';
  await h.send(original); const m = h.got[0].m, range = m.source.display;
  assert.equal(range?.version, 1);
  assert.equal(m.content[0].text.slice(range.start, range.end), original);
  assert.ok(range.id); assert.ok(range.to);
});
test('UI02 tool result carries structured outcome; uncertainty is not failure', async t => {
  const h = await setup(t, { socket: true });
  const r = await h.send('report'); assert.equal(r.display?.outcome, 'queued');
  assert.equal(r.display.target.name, 'beta-bbbb');
  h.a.transport.send = async () => ({ ok: false, error: 'timeout' });
  const timeout = await h.send('other'); assert.equal(timeout.display?.outcome, 'unknown');
  assert.match(timeout.text, /投递状态未知/); assert.doesNotMatch(timeout.text, /当前列表/);
});
